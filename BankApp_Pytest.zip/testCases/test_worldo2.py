from selenium.webdriver.common.by import By
from Utilities import XLutilies


class TestWorldometer:
    path = "D:\\Credence Class Notes\\CredenceBatches\\Credence_Automation_Jul 24\\BankApp_Pytest\\testCases\\Test_Data\\Worldomete_Data2.xlsx"

    def test_worldometer_ddt(self, setup):
        self.driver = setup
        self.driver.get("https://www.worldometers.info/world-population/population-by-country/")
        self.driver.maximize_window()

        # Collect all data first
        data_to_write = []
        rows = self.driver.find_elements(By.XPATH, "//tbody/tr")

        for row_index, row in enumerate(rows, start=1):
            cells = row.find_elements(By.XPATH, "./td")
            row_data = [cell.text for cell in cells]
            data_to_write.append(row_data)

        # Write data to Excel in one operation
        for row_index, row_data in enumerate(data_to_write, start=1):
            for col_index, cell_text in enumerate(row_data, start=1):
                XLutilies.WriteData(self.path, "Sheet1", row_index, col_index, cell_text)

        print("The test case test_worldometer_ddt is completed")
        self.driver.quit()
