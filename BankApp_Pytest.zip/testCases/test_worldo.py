from selenium.webdriver.common.by import By
from Utilities import XLutilies


class TestWorldometer:
    path = "D:\\Credence Class Notes\\CredenceBatches\\Credence_Automation_Jul 24\\BankApp_Pytest\\testCases\\Test_Data\\Worldomete_Data.xlsx"

    def test_worldometer_ddt(self, setup):
        self.driver = setup
        self.driver.get("https://www.worldometers.info/world-population/population-by-country/")
        self.driver.maximize_window()

        # Locate the table rows and columns once to avoid multiple DOM queries
        rows = self.driver.find_elements(By.XPATH, "//tbody/tr")
        cols = len(rows[0].find_elements(By.XPATH, "./td"))

        # Print the number of rows and columns for debugging
        print(f"Rows: {len(rows)}, Columns: {cols}")

        # Write data to Excel, row by row
        for row_index, row in enumerate(rows, start=1):
            cells = row.find_elements(By.XPATH, "./td")
            for col_index, cell in enumerate(cells, start=1):
                cell_text = cell.text
                XLutilies.WriteData(self.path, "data_sheet", row_index, col_index, cell_text)

        print("The test case test_worldometer_ddt is completed")
        self.driver.quit()
